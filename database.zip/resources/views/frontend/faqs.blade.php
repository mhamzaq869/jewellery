@extends('layouts.app')

@section('content')
    <!-- BREADCRUMB -->
    @include('layouts.breadcrumb', ['page' => 'FAQ'])

    <section class="pt-7 pb-12">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 col-xl-8">

                    <!-- Heading -->
                    <h3 class="mb-10 text-center">Frequently Asked Questionss</h3>

                    <!-- Heading -->
                    <h5 class="mb-7">Orders:</h5>

                    <!-- List group -->
                    <ul class="list-group list-group-flush-x mb-9" id="faqCollapseParentOne">
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseOne">
                                1. Bring of had which their whose you're it own?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseOne" data-bs-parent="#faqCollapseParentOne">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseTwo">
                                2. Over shall air can't subdue fly divide him?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseTwo" data-bs-parent="#faqCollapseParentOne">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseThree">
                                3. Waters one you'll creeping?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseThree" data-bs-parent="#faqCollapseParentOne">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseFour">
                                4. Fowl, given morning seed fruitful kind beast be?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseFour" data-bs-parent="#faqCollapseParentOne">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                    </ul>

                    <!-- Heading -->
                    <h5 class="mb-7">Shipping & Returns:</h5>

                    <!-- List group -->
                    <ul class="list-group list-group-flush-x mb-9" id="faqCollapseParentTwo">
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseFive">
                                1. Seas their gathered fruitful whose rule darkness?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseFive" data-bs-parent="#faqCollapseParentTwo">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseSix">
                                2. Evening earth replenish land that his place?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseSix" data-bs-parent="#faqCollapseParentTwo">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseSeven">
                                3. His in fowl morning to upon?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseSeven" data-bs-parent="#faqCollapseParentTwo">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseEight">
                                4. Divide called which created was?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseEight" data-bs-parent="#faqCollapseParentTwo">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseNine">
                                5. Land had man doesn't the very a doesn't?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseNine" data-bs-parent="#faqCollapseParentTwo">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                    </ul>

                    <!-- Heading -->
                    <h5 class="mb-7">Payment:</h5>

                    <!-- List group -->
                    <ul class="list-group list-group-flush-x" id="faqCollapseParentThree">
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseTen">
                                1. Above beginning won't over?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseTen" data-bs-parent="#faqCollapseParentThree">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseEleven">
                                2. Good gathering image called, fifth good?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseEleven" data-bs-parent="#faqCollapseParentThree">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseTwelve">
                                3. Fly beast days dominion firmament?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseTwelve" data-bs-parent="#faqCollapseParentThree">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                        <li class="list-group-item">

                            <!-- Toggle -->
                            <a class="dropdown-toggle d-block fs-lg fw-bold text-reset" data-bs-toggle="collapse"
                                href="#faqCollapseThirteen">
                                4. Fowl, given morning seed fruitful kind beast be?
                            </a>

                            <!-- Collapse -->
                            <div class="collapse" id="faqCollapseThirteen" data-bs-parent="#faqCollapseParentThree">
                                <div class="mt-5">
                                    <p class="mb-0 fs-lg text-gray-500">
                                        Saw wherein fruitful good days image them, midst, waters upon, saw. Seas lights
                                        seasons. Fourth
                                        hath rule creepeth own lesser years itself so seed fifth for grass.
                                    </p>
                                </div>
                            </div>

                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </section>
@endsection
